#include "hash_ring.hpp"
// Implementation is header-only for now, provided in hash_ring.hpp
